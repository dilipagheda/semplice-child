/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'font', 'eo', {
	fontSize: {
		label: 'Grado',
		voiceLabel: 'Tipara grado',
		panelTitle: 'Tipara grado'
	},
	label: 'Tiparo',
	panelTitle: 'Tipara nomo',
	voiceLabel: 'Tiparo'
} );
